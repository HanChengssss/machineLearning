

class DDPG(object):
    def __init__(self, a_dim, s_dim, a_bound,):
        pass

    def choose_action(self, s):
        pass

    def learn(self):
        pass

    def store_transition(self, s, a, r, s_):
        pass



